#-------------------------------------------------------------------------------
# Name:        Howdy!
# Purpose:     Graded Unit Game
#
# Author:      Chloe Third
#
# Created:     20/02/2020
# Copyright:   (c) Catlanta 2020
#
#NO MATTER WHAT I TRIED MUSIC/SOUNDS JUST WOULDNT LOAD SO THEY'VE JUST BEEN COMMENTED.
#-------------------------------------------------------------------------------

import pygame as pg
import sys
from os import path
from random import uniform, choice, randint, random
import time
import random
vec = pg.math.Vector2

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#DECLARING VARIABLES
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#Defining Colours

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
SAND = (237, 201, 175)
BEIGE = (225,203,125)
LGREEN = (208,240,192)
LGRAY = (211,211,211)
LRED = (255, 135, 132)

#Declaring width, height and the title.

WIDTH = 1024
HEIGHT = 750
HALF_WIDTH = WIDTH/2
HALF_HEIGHT = HEIGHT/2
QUARTER_WIDTH = HALF_WIDTH/2
QUARTER_HEIGHT = HALF_HEIGHT/2
FPS = 60
TITLE = "Howdy!"


#declaring tilesize, gridwidth, gridheight

TILESIZE = 32
GRIDWIDTH = WIDTH / TILESIZE
GRIDHEIGHT = HEIGHT / TILESIZE

#Player Settings

PLAYER_HEALTH = 200
PLAYER_SPEED = 300
PLAYER_ROT_SPEED = 200.0
PLAYER_IMG = 'player.png'
PLAYER_HIT_RECT = pg.Rect(0, 0, 35, 35)
BARREL_OFFSET = vec(30, 10)

#Wall Image

WALL_IMG = 'wall2.png'


#Background Image

bg = pg.image.load('background.png')
controls_img = pg.image.load('controls.png')
#win_screen = pg.image.load('win.png')

#Mob Settings

MOB_IMG = ['mob.png','mob2.png','mob3.png']
MOB_SPEED = 200
MOB_HIT_RECT = pg.Rect(0, 0, 30, 30)
MOB_HEALTH = 30
MOB_DAMAGE = 10
MOB_KNOCKBACK = 5
AVOID_RADIUS = 50

#Elite Settings
ELITE_DAMAGE = 25
ELITE_HEALTH = 500
ELITE_IMAGE = 'elite.png'

#Boss Settings

BOSS_DAMAGE = 50
BOSS_HEALTH = 2000
BOSS_IMAGE = 'boss.png'

#Bullet Settings

BULLET_IMG = 'bullet.png'
BULLET_SPEED = 300
BULLET_LIFETIME = 1000
BULLET_RATE = 150
KICKBACK = 200
GUN_SPREAD = 5
BULLET_DAMAGE = 10

#SOUNDS
#BG_MUSIC = 'bg.ogg'

#PLAYER_HIT_SOUNDS = ['pain/8.wav', 'pain/9.wav', 'pain/10.wav', 'pain/11.wav']
#MOB_HIT_SOUNDS = ['splat-15.wav']

#Items

HEALTH_IMG = 'firstaid.png'
SHIELD_IMG = 'shield.png'
SPEED_IMG = 'speed.png'

HEALTH_PACK_AMOUNT = 30


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#EXTRAS#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#First we deal with collisions, we get the positional values of the sprites and ensure that if they collide they don't overlap.

def collide_hit_rect(one, two):
    return one.hit_rect.colliderect(two.rect)

def collide_with_walls(sprite, group, dir):
    if dir == 'x':
        hits = pg.sprite.spritecollide(sprite, group, False, collide_hit_rect)
        if hits:
            if sprite.vel.x > 0:
                sprite.pos.x = hits[0].rect.left - sprite.hit_rect.width / 2
            if sprite.vel.x < 0:
                sprite.pos.x = hits[0].rect.right + sprite.hit_rect.width / 2
            sprite.vel.x = 0
            sprite.hit_rect.centerx = sprite.pos.x
    if dir == 'y':
        hits = pg.sprite.spritecollide(sprite, group, False, collide_hit_rect)
        if hits:
            if sprite.vel.y > 0:
                sprite.pos.y = hits[0].rect.top - sprite.hit_rect.height / 2
            if sprite.vel.y < 0:
                sprite.pos.y = hits[0].rect.bottom + sprite.hit_rect.height / 2
            sprite.vel.y = 0
            sprite.hit_rect.centery = sprite.pos.y

#Drawing the players health based on how much damage they have taken,
#if the players health is full it will appear green.
#If the players health is moderate/half full it will appear yellow.
#If the players health is nearly empty it will appear red.
#This will be drawn at the top left of the screen.

def draw_player_health(surf, x, y, pct):
    if pct < 0:
        pct = 0
    BAR_LENGTH = 100
    BAR_HEIGHT = 20
    fill = pct * BAR_LENGTH
    outline_rect = pg.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
    fill_rect = pg.Rect(x, y, fill, BAR_HEIGHT)
    if pct > 0.6:
        col = GREEN
    elif pct > 0.3:
        col = YELLOW
    else:
        col = RED
    pg.draw.rect(surf, col, fill_rect)
    pg.draw.rect(surf, WHITE, outline_rect, 2)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#MAIN CODE
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Class defining the game, this is where we contain functions for playing the game,
#initiating the game and leveling up through the game.
class Game:
    #Initializing setup
    def __init__(self):
        pg.init()
        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE)
        self.clock = pg.time.Clock()
        self.level = 1
        self.score = 0
        self.game_intro()

    #Creation of the start menu

    def game_intro(self):
        self.intro = True

        while self.intro:
            self.paused = True
            for event in pg.event.get():
                pass
                if event.type == pg.QUIT:
                    self.quit()

            #Calling the background Image
            try:
                self.screen.blit(bg,(0,0))
            except:
                self.screen.fill(BEIGE)
            #Text/Buttons
            largeText = pg.font.Font('freesansbold.ttf',115)
            TextSurf, TextRect = self.text_objects("Howdy!", largeText)
            TextRect.center = ((HALF_WIDTH/2),(QUARTER_HEIGHT/2))

            self.screen.blit(TextSurf, TextRect)

            self.button("Start",50,200,100,50,BEIGE,LGREEN,"play")
            self.button("Controls",50,300,100,50,BEIGE,LGRAY,"controls")
            self.button("Quit",50,400,100,50,BEIGE,LRED,"quit")

            pg.display.update()
    #Function to create the buttons easily
    def button(self,msg,x,y,w,h,ic,ac,action=None):
        self.mouse = pg.mouse.get_pos()
        self.click = pg.mouse.get_pressed()

        if x+w > self.mouse[0] > x and y+h > self.mouse[1] > y:
            pg.draw.rect(self.screen, ac,(x,y,w,h))

            #each button has an action which calls a function specific to that button

            if self.click[0] == 1 and action !=None:
                if action == "quit":
                    self.quit()
                if action == "controls":
                    self.controls_screen()
                if action == "play":
                   self.intro = False
                   self.controls = False
                   self.load_data()
                   self.new()
                   self.show_go_screen()
                   self.run()

        else:
            pg.draw.rect(self.screen, ic,(x,y,w,h),1)

        smallText = pg.font.Font("freesansbold.ttf",20)
        TextSurf, TextRect = self.text_objects(msg, smallText)
        TextRect.center = ( (x+(w/2)), (y+(h/2)) )
        self.screen.blit(TextSurf, TextRect)

    def text_objects(self, text, font):
        textSurface = font.render(text, True, BLACK)
        return textSurface, textSurface.get_rect()

    def draw_text(self, text, font_name, size, color, x, y, align="topleft"):
        font = pg.font.Font(font_name, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect(**{align: (x, y)})
        self.screen.blit(text_surface, text_rect)

    #display controls
    #This wasnt coded in, its simply a picture blitted.

    def controls_screen(self):
        self.controls = True
        while self.controls:
            for event in pg.event.get():
                pass
                if event.type == pg.QUIT:
                    pg.quit()
                    quit()
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_ESCAPE:
                        self.controls = False
                        self.game_intro()
            try:
                self.screen.blit(controls_img,(0,0))
            except:
                self.screen.fill(BEIGE)

            pg.display.update()
        pass

    #Loading all the images for the game

    def load_data(self):
        #Declaring all the folders
        game_folder = path.dirname(__file__)
        img_folder = path.join(game_folder, 'img')
        music_folder = path.join(game_folder, 'music')
        #snd_folder = path.join(game_folder, 'snd')

        #Player Image
        self.player_img = pg.image.load(path.join(img_folder, PLAYER_IMG)).convert_alpha()

        #self.player_hit_sounds = []
        #for snd in PLAYER_HIT_SOUNDS:
            #self.player_hit_sounds.append(pg.mixer.Sound(path.join(snd_folder, snd)))

        #Wall Images/Size
        self.wall_img = pg.image.load(path.join(img_folder, WALL_IMG)).convert_alpha()
        self.wall_img = pg.transform.scale(self.wall_img, (TILESIZE, TILESIZE))

        #List of Mob Images, so mobs don't all look the same, if you look closely ;)
        self.mob_img = []
        for img in MOB_IMG:
            self.mob_img.append(pg.image.load(path.join(img_folder, img)).convert_alpha())

        #self.mob_hit_sounds = []
        #for snd in MOB_HIT_SOUNDS:
            #self.mob_hit_sounds.append(pg.mixer.Sound(path.join(snd_folder, snd)))


        #Elite Image
        self.elite_img = pg.image.load(path.join(img_folder, ELITE_IMAGE)).convert_alpha()
        #Boss Image

        self.boss_img = pg.image.load(path.join(img_folder, BOSS_IMAGE)).convert_alpha()

        #Health Image (Little Red Plus)
        self.health_img = pg.image.load(path.join(img_folder,HEALTH_IMG)).convert_alpha()

        #Bullet Images

        self.bullet_img = pg.image.load(path.join(img_folder, BULLET_IMG)).convert_alpha()

        #Fonts

        self.title_font = path.join(img_folder, 'font.otf')
        self.hud_font = path.join(img_folder, 'Impacted2.0.ttf')
        #Load Music
        #pg.mixer.music.load(path.join(music_folder, BG_MUSIC))


    #Starts a new game!, This is how I spawn in a new map for each level.
    def new(self):

        #Adding all of these to the group
        self.all_sprites = pg.sprite.Group()
        self.walls = pg.sprite.Group()
        self.bullets = pg.sprite.Group()
        self.mobs = pg.sprite.Group()
        self.elite = pg.sprite.Group()
        self.boss = pg.sprite.Group()
        self.health = pg.sprite.Group()
        #Changes returns the level number, and returns the specific map depending on that.
        self.level_up()
        self.map = self.level_up()

        #Reading the map! spawning based on the following Letters/Numbers in the map txt file
        for row, tiles in enumerate(self.map.data):
            for col, tile in enumerate(tiles):
                if tile == '1':
                    Wall(self, col, row)
                if tile == 'P':
                    self.player = Player(self, col, row)
                if tile == 'M':
                    Mob(self, col, row)
                if tile == 'H':
                    Health(self, col, row)
                if tile == 'E':
                    Elite(self,col, row)
                if tile == 'B':
                    Boss(self, col, row)

        #Pausing the game
        self.paused = False

    def run(self):
        #Running the game, ticks, and pausing again.
        self.playing = True
        #pg.mixer.music.play(loops=-1)
        while self.playing:
            self.dt = self.clock.tick(FPS) / 1000
            self.events()
            if not self.paused:
                    self.level_up()
                    self.update()
            self.draw()

    #This is where we check for collisions, bullets hitting mobs, mobs hitting players and leveling up!
    def update(self):
        self.load_data()
        self.all_sprites.update()

        #Check for Leveling Up
        if len(self.mobs) == 0 and len(self.boss) == 0 and len(self.elite) == 0:
                self.level += 1
                self.level_up()
                self.playing = False

        #Colliding players and mobs. (Players take damage based on mob damage)
        hits = pg.sprite.spritecollide(self.player, self.mobs, False, collide_hit_rect)
        for hit in hits:
            #if random() < 0.7:
                #choice(self.player_hit_sounds).play()
            self.player.health -= MOB_DAMAGE
            hit.vel = vec(0, 0)
            if self.player.health <= 0:
                self.game_over()
            #Knockback is buggy, it pushes the player through walls occasionally
            #self.player.pos += vec(MOB_KNOCKBACK, 0).rotate(-hits[0].rot)

        hits = pg.sprite.spritecollide(self.player, self.boss, False, collide_hit_rect)
        for hit in hits:
            #if random() < 0.7:
                #choice(self.player_hit_sounds).play()
            self.player.health -= BOSS_DAMAGE
            hit.vel = vec(0, 0)
            if self.player.health <= 0:
                self.game_over()
            #Knockback is buggy, it pushes the player through walls occasionally
            #self.player.pos += vec(MOB_KNOCKBACK, 0).rotate(-hits[0].rot)

        hits = pg.sprite.spritecollide(self.player, self.elite, False, collide_hit_rect)
        for hit in hits:
            #if random() < 0.7:
                #choice(self.player_hit_sounds).play()
            self.player.health -= ELITE_DAMAGE
            hit.vel = vec(0, 0)
            if self.player.health <= 0:
                self.game_over()
            #Knockback is buggy, it pushes the player through walls occasionally
            #self.player.pos += vec(MOB_KNOCKBACK, 0).rotate(-hits[0].rot)


        #Mobs colliding with bullets, score goes up based on mob deaths.
        hits = pg.sprite.groupcollide(self.mobs, self.bullets, False, True)
        for hit in hits:
            hit.health -= BULLET_DAMAGE
            hit.vel = vec(0, 0)
            if hit.health <= 0:
                self.score += 100
                return self.score

        #Bosses (same as mobs)
        hits = pg.sprite.groupcollide(self.boss, self.bullets, False, True)
        for hit in hits:
            hit.health -= BULLET_DAMAGE
            hit.vel = vec(0, 0)
            if hit.health <= 0:
                self.score += 500
                return self.score

        hits = pg.sprite.groupcollide(self.elite, self.bullets, False, True)
        for hit in hits:
            hit.health -= BULLET_DAMAGE
            hit.vel = vec(0, 0)
            if hit.health <= 0:
                self.score += 250
                return self.score

        #Player health goes up when interacting with the +)
        hits = pg.sprite.spritecollide(self.player, self.health, False)
        for hit in hits:
            if self.player.health < PLAYER_HEALTH:
                hit.kill()
                self.player.add_health(HEALTH_PACK_AMOUNT)



    #Heres where we draw everything, the background, sprites, player health, text and the paused lettering.
    def draw(self):
        self.screen.blit(bg,(0,0))
        self.all_sprites.draw(self.screen)
        draw_player_health(self.screen, 10, 10, self.player.health / PLAYER_HEALTH)
        self.draw_text("Score: "+str(self.score), self.title_font, 24, BLACK, HALF_WIDTH, 15, align="center")
        if self.paused:
            self.draw_text("Paused", self.title_font, 105, WHITE, WIDTH / 2, HEIGHT / 2, align="center")
        pg.display.flip()


    #Quit function, for quitting duh.
    def quit(self):
        pg.quit()
        sys.exit()

    #Here is where I determine the map via level. As seen in update
    #Everytime the number of mobs hits 0, the level is increased by 1
    #Utilizing update to change the map path to the next map, and
    #Allowing draw to redraw it again.
    def level_up(self):
        game_folder = path.dirname(__file__)
        if self.level == 1:
            self.map = Map(path.join(game_folder, 'map.txt'))
            return self.map
        if self.level == 2:
            self.map = Map(path.join(game_folder, 'map2.txt'))
            return self.map
        if self.level == 3:
            self.map = Map(path.join(game_folder, 'map3.txt'))
            return self.map
        if self.level == 4:
            self.map = Map(path.join(game_folder, 'map4.txt'))
            return self.map
        if self.level == 5:
            self.map = Map(path.join(game_folder, 'map5.txt'))
            return self.map
        if self.level == 6:
            self.map = Map(path.join(game_folder, 'map6.txt'))
            return self.map
        if self.level == 7:
            self.map = Map(path.join(game_folder, 'map7.txt'))
            return self.map
        if self.level == 8:
            self.map = Map(path.join(game_folder, 'map8.txt'))
            return self.map
        if self.level == 9:
            self.map = Map(path.join(game_folder, 'map9.txt'))
            return self.map
        if self.level == 10:
            self.map = Map(path.join(game_folder, 'map10.txt'))
            return self.map
        #If the player wins.
        if self.level == 11:
            self.game_complete()

    #Event Handling! (also where we determine if the game is paused)
    def events(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.quit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_ESCAPE:
                    self.quit()
                if event.key == pg.K_p:
                    self.paused = not self.paused

    #Go Screen! This is the white text that appears when you hit start in the menu.
    #It allows the game to start upon button press instead of starting while the menu
    #Is in use!
    def show_go_screen(self):
        try:
            self.screen.blit(bg,(0,0))
        except:
            self.screen.fill(BEIGE)
        self.draw_text("Press a key to start", self.title_font, 75, WHITE, WIDTH / 2, HEIGHT/2, align="center")
        self.draw_text("Eliminate the sheriffs!", self.title_font, 75, WHITE, WIDTH / 2, QUARTER_HEIGHT, align="center")
        pg.display.flip()
        self.wait_for_key()
    #Game over text, for when the players health reaches 0
    def game_over(self):
        try:
            self.screen.blit(bg,(0,0))
        except:
            self.screen.fill(BEIGE)
        self.draw_text("Game Over", self.title_font, 75, RED, WIDTH / 2, HEIGHT/2, align="center")
        pg.display.flip()
        self.level = 1
        self.wait_for_key()
        self.intro = True
        self.game_intro()

    #Game complete screen, when the level hits 11
    def game_complete(self):
        try:
            self.screen.blit(bg,(0,0))
        except:
            self.screen.fill(BEIGE)
        self.draw_text("Game Complete!", self.title_font, 75, WHITE, WIDTH / 2, HEIGHT/2, align="center")
        self.draw_text("Thanks for playing!", self.title_font, 75, WHITE, WIDTH / 2, QUARTER_HEIGHT, align="center")
        pg.display.flip()
        self.wait_for_key()
        self.quit()

    #Waits for button press before doing something.
    def wait_for_key(self):
        pg.event.wait()
        waiting = True
        while waiting:
            self.clock.tick(FPS)
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    waiting = False
                    self.quit()
                if event.type == pg.KEYUP:
                    waiting = False


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#PLAYER CLASS
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Player class, this is what the user controls, declares all their values, declares how the user moves etc
class Player(pg.sprite.Sprite):
        def __init__(self, game, x, y):
            self.groups = game.all_sprites
            pg.sprite.Sprite.__init__(self, self.groups)
            self.game = game
            self.image = game.player_img
            self.rect = self.image.get_rect()
            self.hit_rect = PLAYER_HIT_RECT
            self.hit_rect.center = self.rect.center
            self.vel = vec(0, 0)
            self.pos = vec(x, y) * TILESIZE
            self.health = PLAYER_HEALTH
            self.speed = PLAYER_SPEED
            self.damage = BULLET_DAMAGE
            self.rot = 0
            self.last_shot = 0

        def get_keys(self):
            self.rot_speed = 0
            self.vel = vec(0, 0)
            #Character Moving Up/Down/left/Right
            keys = pg.key.get_pressed()
            if keys[pg.K_a]:
                self.vel.x = -PLAYER_SPEED
            if keys[pg.K_d]:
                self.vel.x = PLAYER_SPEED
            if keys[pg.K_w]:
                self.vel.y = -PLAYER_SPEED
            if keys[pg.K_s]:
                self.vel.y = PLAYER_SPEED
            #Aim (Rotates)
            if keys[pg.K_LEFT]:
                self.rot_speed = PLAYER_ROT_SPEED
            if keys[pg.K_RIGHT]:
                self.rot_speed = -PLAYER_ROT_SPEED
            #Shooting upon space press.
            if keys[pg.K_SPACE]:
                now = pg.time.get_ticks()
                if now - self.last_shot > BULLET_RATE:
                    self.last_shot = now
                    dir = vec(1, 0).rotate(-self.rot)
                    pos = self.pos + BARREL_OFFSET.rotate(-self.rot)
                    Bullet(self.game, pos, dir)
                    self.vel = vec(-KICKBACK, 0).rotate(-self.rot)

        def update(self):
            self.get_keys()
            self.rot = (self.rot + self.rot_speed * self.game.dt) % 360
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            self.pos += self.vel * self.game.dt
            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
        #Adds health
        def add_health(self, amount):
            self.health += amount
            if self.health > PLAYER_HEALTH:
                self.health = PLAYER_HEALTH




#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#MOB CLASS
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Mob class, used to create the enemy of the player, declares images health dimensions etc
class Mob(pg.sprite.Sprite):
        def __init__(self, game, x, y):
            self.groups = game.all_sprites, game.mobs
            pg.sprite.Sprite.__init__(self, self.groups)
            self.game = game
            self.image = pg.transform.scale(choice(game.mob_img), (34, 23))
            self.rect = self.image.get_rect()
            self.hit_rect = MOB_HIT_RECT.copy()
            self.hit_rect.center = self.rect.center
            self.pos = vec(x, y) * TILESIZE
            self.vel = vec(0, 0)
            self.acc = vec(0, 0)
            self.rect.center = self.pos
            self.rot = 0
            self.health = MOB_HEALTH


        def update(self):
            self.rot = (self.game.player.pos - self.pos).angle_to(vec(1, 0))
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            self.acc = vec(MOB_SPEED, 0).rotate(-self.rot)
            self.acc += self.vel * -1
            self.vel += self.acc * self.game.dt
            self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2

            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
            if self.health <= 0:
                self.kill()


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#BOSS CLASS
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Stronger Mob, Same properties just more health and damage.
class Boss(pg.sprite.Sprite):
        def __init__(self, game, x, y):
            self.groups = game.all_sprites, game.boss
            pg.sprite.Sprite.__init__(self, self.groups)
            self.game = game
            self.image = game.boss_img
            self.rect = self.image.get_rect()
            self.hit_rect = MOB_HIT_RECT.copy()
            self.hit_rect.center = self.rect.center
            self.pos = vec(x, y) * TILESIZE
            self.vel = vec(0, 0)
            self.acc = vec(0, 0)
            self.rect.center = self.pos
            self.rot = 0
            self.health = BOSS_HEALTH



        def update(self):
            self.rot = (self.game.player.pos - self.pos).angle_to(vec(1, 0))
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            self.acc = vec(MOB_SPEED, 0).rotate(-self.rot)
            self.acc += self.vel * -1
            self.vel += self.acc * self.game.dt
            self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2

            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
            if self.health <= 0:
                self.kill()


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Elite Class
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


class Elite(pg.sprite.Sprite):
        def __init__(self, game, x, y):
            self.groups = game.all_sprites, game.elite
            pg.sprite.Sprite.__init__(self, self.groups)
            self.game = game
            self.image = game.elite_img
            self.rect = self.image.get_rect()
            self.hit_rect = MOB_HIT_RECT.copy()
            self.hit_rect.center = self.rect.center
            self.pos = vec(x, y) * TILESIZE
            self.vel = vec(0, 0)
            self.acc = vec(0, 0)
            self.rect.center = self.pos
            self.rot = 0
            self.health = ELITE_HEALTH


        def update(self):
            self.rot = (self.game.player.pos - self.pos).angle_to(vec(1, 0))
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            self.acc = vec(MOB_SPEED, 0).rotate(-self.rot)
            self.acc += self.vel * -1
            self.vel += self.acc * self.game.dt
            self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2

            self.hit_rect.centerx = self.pos.x
            collide_with_walls(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            collide_with_walls(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
            if self.health <= 0:
                self.kill()


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#BULLET CLASS
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Bullets the user shoots, declares gunspread, speed, image etc
class Bullet(pg.sprite.Sprite):
    def __init__(self, game, pos, dir):
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.bullet_img
        self.rect = self.image.get_rect()
        self.pos = vec(pos)
        self.rect.center = pos
        spread = uniform(-GUN_SPREAD, GUN_SPREAD)
        self.vel = dir.rotate(spread) * BULLET_SPEED
        self.spawn_time = pg.time.get_ticks()
        self.damage = BULLET_DAMAGE

    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        if pg.sprite.spritecollideany(self, self.game.walls):
            self.kill()


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#WALL CLASS
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Creates walls for the game, declares their size and image
class Wall(pg.sprite.Sprite):
        def __init__(self, game, x, y):
            self.groups = game.all_sprites, game.walls
            pg.sprite.Sprite.__init__(self, self.groups)
            self.game = game
            self.image = pg.Surface((TILESIZE, TILESIZE))
            self.image = game.wall_img
            self.rect = self.image.get_rect()
            self.x = x
            self.y = y
            self.rect.x = x * TILESIZE
            self.rect.y = y * TILESIZE

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#MAP CLASS
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Where the map txt file is read and appended
class Map:
    def __init__(self, filename):
        self.data = []
        with open(filename, 'rt') as f:
            for line in f:
                self.data.append(line.strip())

        self.tilewidth = len(self.data[0])
        self.tileheight = len(self.data)
        self.width = self.tilewidth * TILESIZE
        self.height = self.tileheight * TILESIZE

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Item Class
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Defining item properties

class Health(pg.sprite.Sprite):
    def __init__(self, game,x,y):
        self.groups = game.all_sprites, game.health
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = pg.Surface((TILESIZE, TILESIZE))
        self.image = game.health_img
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.x = x * TILESIZE
        self.rect.y = y * TILESIZE




g = Game()
while True:
    g.new()
    g.run()

